//Contains @value, @throws, @link
package example.identification;

import example.common.InvalidDataException;

/**
 * A class representing an identifiable object. This class implements the
 * {@link example.identification.Identifiable Identifiable interface}. It
 * contains 1 string parameter which acts as the identifier.
 *
 * @since 1.0
 * @see example.identification.Identifiable
 * @see example.common.IdentifiableImplFactory
 * @author elee
 */
public class IdentifiableImpl implements Identifiable {

    /**
     * The string which acts as the identifier for this object
     *
     * @see #getIdentifier()
     */
    private String identifier;

    /**
     * A fake field created for the purpose of demonstrating the value tag. The
     * value of the constant is {@value}.
     *
     */
    private static final int constant = 1500;

    /**
     * Creates a new Identifiable Implement object, and sets the
     * {@link #identifier identifier} with the input parameter id.
     *
     * @param id The input string which sets the objects identifier field.
     * @throws InvalidDataException Throws when input is null or string is
     * empty.
     */
    public IdentifiableImpl(String id) throws InvalidDataException {
        setIdentifier(id);
    }

    /**
     * Returns the identifier field of the identifiable object.
     *
     * @return The string held in the identifier field.
     */
    @Override
    public String getIdentifier() {
        return identifier;
    }

    /**
     * Sets the identifier of the identifiable object. The input may not be
     * null, nor the id string empty.
     *
     * @param id The input string which sets the identifier field.
     * @throws InvalidDataException Throws when input is null or string is
     * empty.
     */
    public final void setIdentifier(String id) throws InvalidDataException {
        if (id == null || id.length() == 0) {
            throw new InvalidDataException("Null or empty ID passed to setIdentifier");
        }
        identifier = id;
    }
}
