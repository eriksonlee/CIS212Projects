package example.location;

import example.common.InvalidDataException;
import example.common.Point3D;

/**
 * A class representing a locatable object. This object contains a reference to
 * a 3D point object which identifies the location of this locatable object.
 *
 * @see example.common.LocatableImplFactory
 * @author elee
 */
public class LocatableImpl implements Locatable {

    /**
     * The 3D point object which acts as the location of the locatable object.
     *
     * @see example.common.Point3D
     */
    private final Point3D location = new Point3D();

    /**
     * Creates a new locatable object based on the coordinates of the 3D point
     * object passed through.
     *
     * @param loc The 3D point object whose location will set this locatable
     * object's location
     * @throws InvalidDataException Throws if the 3D point object references
     * null
     */
    public LocatableImpl(Point3D loc) throws InvalidDataException {
        setLocation(loc);
    }

    /**
     * Creates a new locatable object based on 3 coordinate values passed
     * through.
     *
     * @param x The X value to set the locatable object's X value
     * @param y The Y value to set the locatable object's Y value
     * @param z The Z value to set the locatable object's Z value
     * @throws InvalidDataException Throws if the coordinate values are negative
     */
    public LocatableImpl(double x, double y, double z) throws InvalidDataException {
        this(new Point3D(x, y, z));
    }

    /**
     * Gets the location of the locatable object in the form of a 3D point
     * object.
     *
     * @return A 3D point object whose coordinates match the locatable object's
     * location.
     */
    @Override
    public Point3D getLocation() {
        return new Point3D(location);
    }

    /**
     * Gets the X coordinate of the locatable object.
     *
     * @return A value which represents the X coordinate of the locatable
     * object.
     */
    @Override
    public double getLocationX() {
        return location.getX();
    }

    /**
     * Gets the Y coordinate of the locatable object.
     *
     * @return A value which represents the Y coordinate of the locatable
     * object.
     */
    @Override
    public double getLocationY() {
        return location.getY();
    }

    /**
     * Gets the Z coordinate of the locatable object.
     *
     * @return A value which represents the Z coordinate of the locatable
     * object.
     */
    @Override
    public double getLocationZ() {
        return location.getZ();
    }

    /**
     * Sets the location of the locatable object based on a 3D point object.
     * This method takes the X, Y, and Z coordinates of the 3D point object
     * passed through, and sets the X, Y, and Z coordinates of this locatable
     * object's 3D point object.
     *
     * @param loc A 3D point object whose coordinates will be used to set this
     * locatable object's location.
     * @throws InvalidDataException Throws if the 3D point object passed through
     * references null.
     */
    @Override
    public final void setLocation(Point3D loc) throws InvalidDataException {
        if (loc == null) {
            throw new InvalidDataException("Null location sent to setLocation");
        }

        setLocation(loc.getX(), loc.getY(), loc.getZ());
    }

    /**
     * Sets the location of the locatable object based on 3 coordinate
     * parameters. This method takes the X, Y, and Z parameters passed through,
     * and sets the X, Y, and Z coordinates of this locatable object's 3D point
     * object.
     *
     * @param x The X coordinate of the desired location
     * @param y The Y coordinate of the desired location
     * @param z The Z coordinate of the desired location
     * @throws InvalidDataException Throws if any of the coordinate values are
     * negative.
     */
    @Override
    public void setLocation(double x, double y, double z) throws InvalidDataException {
        if (x < 0.0 || y < 0.0 || z < 0.0) {
            throw new InvalidDataException("Invalid X,Y,Z point sent to setLocation(x,y,z)");
        }
        location.setCoordinates(x, y, z);
    }

    /**
     * Returns the distance between this locatable object's location and the
     * location of the passed-through 3D point object.
     *
     * @param loc A 3D point whose location will be used to calculate distance.
     * @return The distance between this locatable object's location and the
     * passed-through 3D point's location.
     * @throws InvalidDataException Throws if the passed-through 3D point object
     * references null.
     */
    @Override
    public double distance(Point3D loc) throws InvalidDataException {
        if (loc == null) {
            throw new InvalidDataException("Null location sent to distance");
        }
        return location.distance(loc);
    }

    /**
     * Returns the distance between this locatable object's location and the
     * location represented by the 3 coordinates passed-through.
     *
     * @param x The X value of the location whose distance we are calculating
     * @param y The Y value of the location whose distance we are calculating
     * @param z The Z value of the location whose distance we are calculating
     * @return The distance between this locatable object's location and the
     * location represented by the 3 coordinates.
     * @throws InvalidDataException Throws if the coordinate values are
     * negative.
     */
    @Override
    public double distance(double x, double y, double z) throws InvalidDataException {
        if (x < 0.0 || y < 0.0 || z < 0.0) {
            throw new InvalidDataException("Invalid X,Y,Z point sent to distance(x,y,z)");
        }
        return location.distance(x, y, z);
    }
}
