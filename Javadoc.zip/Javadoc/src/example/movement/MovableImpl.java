package example.movement;

import example.common.InvalidDataException;
import example.common.LocatableImplFactory;
import example.common.Point3D;
import example.location.Locatable;

/**
 * This class represents a movable object. This movable object contains a
 * destination, a speed value, a max speed value, and a locatable object.
 *
 * @author elee
 */
public class MovableImpl implements Movable {

    /**
     * The Point3D object which represents the destination of this movable
     * object.
     */
    private final Point3D destination = new Point3D();

    /**
     * The current speed of this movable object. This cannot exceed the max
     * speed.
     */
    private double speed;

    /**
     * The maximum speed of this movable object. This cannot be less than the
     * current speed.
     */
    private double maxSpeed;

    /**
     * The locatable object of this movable object.
     */
    private Locatable myLocatable;

    /**
     * Creates a new movable object with a location and destination derived from
     * Point3D objects. Also requires a speed and max speed value.
     *
     * @param loc A Point3D object used to create the locatable object owned by
     * this movable object.
     * @param dest A Point3D object used to set the distance field of this
     * movable object.
     * @param spd A value used to set the current speed of the movable object.
     * This value may not exceed the max speed. This value may not be negative.
     * @param mxSpd A value used to set the maximum speed of the movable object.
     * This value may not be less than the current speed. This value may not be
     * negative.
     * @throws InvalidDataException Throws if the passed-through objects
     * reference null, or if the speed and max speed values are negative.
     *
     */
    public MovableImpl(Point3D loc, Point3D dest, double spd, double mxSpd) throws InvalidDataException {
        setLocatable(LocatableImplFactory.createLocatable(loc));
        setDestination(dest);
        setMaxSpeed(mxSpd);
        setSpeed(spd);
    }

    /**
     * Creates a new movable object with a location and destination derived from
     * 2 sets of 3 coordinates passed-through. Also requires a speed and max
     * speed value.
     *
     * @param lX The X value used to create the locatable object reference.
     * @param lY The Y value used to create the locatable object reference.
     * @param lZ The Z value used to create the locatable object reference.
     * @param dX The X value used to create Point3D object representing the
     * destination.
     * @param dY The Y value used to create Point3D object representing the
     * destination.
     * @param dZ The Z value used to create Point3D object representing the
     * destination.
     * @param spd The value used to set the current speed of the movable object.
     * @param mxSpd The value used to set the maximum speed of the movable
     * object.
     * @throws InvalidDataException Throws if any of the input parameters are
     * negative.
     */
    public MovableImpl(double lX, double lY, double lZ, double dX, double dY, double dZ,
            double spd, double mxSpd) throws InvalidDataException {
        setLocatable(LocatableImplFactory.createLocatable(new Point3D(lX, lY, lZ)));
        setDestination(dX, dY, dZ);
        setMaxSpeed(mxSpd);
        setSpeed(spd);
    }

    /**
     * Sets the reference to the locatable object for this movable object.
     *
     * @param li The locatable object passed-through to set this movable
     * object's locatable object.
     * @throws InvalidDataException Throws if the passed-through Locatable
     * object references null.
     */
    private void setLocatable(Locatable li) throws InvalidDataException {
        if (li == null) {
            throw new InvalidDataException("Null Locatable sent to setLocatable.");
        }
        myLocatable = li;
    }

    /**
     * Returns the locatable object of this movable object.
     *
     * @return The locatable object.
     */
    private Locatable getLocatable() {
        return myLocatable;
    }

    /**
     * Returns a Point3D object representing the destination of this movable
     * object.
     *
     * @return The Point3D representing the destination of this movable object.
     */
    @Override
    public Point3D getDestination() {
        if (destination == null) {
            return null;
        }
        return new Point3D(destination);
    }

    /**
     * Returns the X coordinate of the Point3D object representing this movable
     * object's destination.
     *
     * @return The X coordinate of this movable object's destination
     */
    @Override
    public double getDestinationX() {
        return destination.getX();
    }

    /**
     * Returns the Y coordinate of the Point3D object representing this movable
     * object's destination.
     *
     * @return The Y coordinate of this movable object's destination
     */
    @Override
    public double getDestinationY() {
        return destination.getY();
    }

    /**
     * Returns the Z coordinate of the Point3D object representing this movable
     * object's destination.
     *
     * @return The Z coordinate of this movable object's destination
     */
    @Override
    public double getDestinationZ() {
        return destination.getZ();
    }

    /**
     * Sets the location of the Point3D object representing this movable
     * object's destination, based on 3 coordinates entered as parameters.
     *
     * @param x The X coordinate of the desired destination
     * @param y The Y coordinate of the desired destination
     * @param z The Z coordinate of the desired destination
     * @throws InvalidDataException Throws if any of the input parameters are
     * negative.
     */
    @Override
    public final void setDestination(double x, double y, double z) throws InvalidDataException {
        if (x < 0.0 || y < 0.0 || z < 0.0) {
            throw new InvalidDataException(
                    "Invalid X,Y,Z point sent to setDestination(x,y,z): (" + x + "," + y + "," + z + ")");
        }
        destination.setLocation(x, y, z);
    }

    /**
     * Sets the location of the Point3D object representing this movable
     * object's destination, based on another Point3D object's location.
     *
     * @param aPoint The Point3D object whose location is used to set this
     * movable object's destination.
     * @throws InvalidDataException Throws if the passed-through Point3D object
     * references null
     */
    @Override
    public final void setDestination(Point3D aPoint) throws InvalidDataException {
        if (aPoint == null) {
            throw new InvalidDataException("Null Point3D sent to setDestination(Point3D)");
        }
        setDestination(aPoint.getX(), aPoint.getY(), aPoint.getZ());
    }

    /**
     * Gets the current speed of movable object.
     *
     * @return The current speed of the movable object.
     */
    @Override
    public double getSpeed() {
        return speed;
    }

    /**
     * Sets the current speed of the movable object. Current speed cannot be
     * less than 0, nor can it exceed max speed value.
     *
     * @param s The speed value passed through to set the current speed of the
     * movable object.
     * @throws InvalidDataException Throws if the input speed is less than 0, or
     * if it exceeds the maximum speed.
     */
    @Override
    public final void setSpeed(double s) throws InvalidDataException {
        if (s < 0.0) {
            throw new InvalidDataException("Negative speed sent to setSpeed:" + s);
        }
        if (s > getMaxSpeed()) {
            throw new InvalidDataException("Attempt to set speed (" + s + ") greater than maxSpeed (" + getMaxSpeed()
                    + ") in setSpeed");
        }
        speed = s;
    }

    /**
     * Gets the maximum speed value of this movable object.
     *
     * @return The value set for maximum speed.
     */
    @Override
    public double getMaxSpeed() {
        return maxSpeed;
    }

    /**
     * Sets the maximum speed value of the movable object. The maximum speed
     * value may not be negative, nor be less than the current speed of the
     * movable object.
     *
     * @param ms The maximum speed value passed through to set the maximum speed
     * of this movable object.
     * @throws InvalidDataException Throws if the maximum speed input is less
     * than 0 or is less than the current speed.
     */
    @Override
    public final void setMaxSpeed(double ms) throws InvalidDataException {
        if (ms < 0.0) {
            throw new InvalidDataException("Negative maxSpeed sent to setMaxSpeed:" + ms);
        }
        if (ms < getSpeed()) {
            throw new InvalidDataException("Attempt to set maxSpeed less than speed in setMaxSpeed: " + ms);
        }
        maxSpeed = ms;
    }

    /**
     * Returns true if the location coordinates of the movable object are equal
     * to the destination coordinates of the same movable object.
     *
     * @return Boolean indicating whether the coordinates of the location
     * Point3D are the same as the coordinates of the destination Point3D.
     */
    @Override
    public boolean atDestination() {
        return myLocatable.getLocation().equals(destination);
    }

    /**
     * Calculates the distance between the location of the passed-through
     * Point3D object and the location of the current movable object.
     *
     * @param loc The Point3D object whose location will be used to calculate
     * the distance
     * @return The distance between the location of this movable object and the
     * location of the passed-through Point3D.
     * @throws InvalidDataException Throws if the Point3D object passed through
     * references null.
     */
    // From Locatable interface
    @Override
    public double distance(Point3D loc) throws InvalidDataException {
        return myLocatable.distance(loc);
    }

    /**
     * Calculates the distance between the location referenced by the 3
     * coordinates passed-through and the location of the current movable
     * object.
     *
     * @param x The X coordinate of the location to calculate distance
     * @param y The Y coordinate of the location to calculate distance
     * @param z The Z coordinate of the location to calculate distance
     * @return The distance between the location of this movable object and the
     * location referenced by the 3 coordinates passed-through.
     * @throws InvalidDataException Throws if the passed-through coordinate
     * values are negative.
     */
    @Override
    public double distance(double x, double y, double z) throws InvalidDataException {
        return myLocatable.distance(x, y, z);
    }

    /**
     * Gets the location of this movable object in the form of a Point3D object
     *
     * @return A Point3D object representing the location of this movable object
     */
    @Override
    public Point3D getLocation() {
        return myLocatable.getLocation();
    }

    /**
     * Gets the X coordinate of the location of this movable object.
     *
     * @return A value representing the X coordinate of this movable object's
     * location.
     */
    @Override
    public double getLocationX() {
        return myLocatable.getLocationX();
    }

    /**
     * Gets the Y coordinate of the location of this movable object.
     *
     * @return A value representing the Y coordinate of this movable object's
     * location.
     */
    @Override
    public double getLocationY() {
        return myLocatable.getLocationY();
    }

    /**
     * Gets the Z coordinate of the location of this movable object.
     *
     * @return A value representing the Z coordinate of this movable object's
     * location.
     */
    @Override
    public double getLocationZ() {
        return myLocatable.getLocationZ();
    }

    /**
     * Sets the location of this movable object, based on the location of a
     * Point3D object passed through. Creates a new Locatable object belonging
     * to this Movable object.
     *
     * @param loc The Point3D object representing the location desired.
     * @throws InvalidDataException Throws if the Point3D object references null
     */
    @Override
    public void setLocation(Point3D loc) throws InvalidDataException {
        myLocatable.setLocation(loc);
    }

    /**
     * Sets the location of this movable object based on 3 coordinate parameters
     * passed through. Creates a new Locatable object belonging to this Movable
     * object.
     *
     * @param x The X coordinate of the desired location.
     * @param y The Y coordinate of the desired location.
     * @param z The Z coordinate of the desired location.
     * @throws InvalidDataException Throws if any of the coordinates are
     * negative.
     */
    @Override
    public void setLocation(double x, double y, double z) throws InvalidDataException {
        myLocatable.setLocation(x, y, z);
    }

    /**
     * Updates the location of this movable object based on the amount of time
     * which has passed.
     *
     * @param millis
     * @throws InvalidDataException Throws if the destination object for this
     * movable object references null, or if the newly derived coordinates are
     * negative.
     */
    @Override
    public void update(double millis) throws InvalidDataException {
        // This is a FAKE update method - NOT what you need for your project.
        double time = millis / 1000.0;

        double distanceTraveled = getSpeed() * time;
        double distance = getLocation().distance(getDestination());

        if (distance == 0.0) {
            return;
        }
        if (distanceTraveled >= distance) {
            setLocation(destination);
            return;
        }
        double delta = distanceTraveled / distance;

        double newX = getLocation().getX() + (getDestination().getX() - getLocation().getX()) * delta;
        double newY = getLocation().getY() + (getDestination().getY() - getLocation().getY()) * delta;
        double newZ = getLocation().getZ() + (getDestination().getZ() - getLocation().getZ()) * delta;

        setLocation(newX, newY, newZ);

    }
}
