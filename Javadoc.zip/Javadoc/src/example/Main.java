package example;

import example.common.InvalidDataException;
import example.common.Point3D;
import example.identification.Identifiable;
import example.identification.IdentifiableImpl;
import example.location.Locatable;
import example.location.LocatableImpl;
import example.movement.Movable;
import example.movement.MovableImpl;



/*
 Expected output from this "main" is found in comments at the end of the file.
 */
public class Main {

    public static void main(String[] args) {

        try {
            makePoints();
            makeIdentification();
            makeLocation();
            makeMovement();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private static void makeMovement() throws InvalidDataException {
        
        Movable m1 = new MovableImpl(new Point3D(100.2, 202.5, 141.7), new Point3D(10.0, 20.0, 30.0), 20.0, 65.0);
        Movable m2 = new MovableImpl(16.5, 44.1, 59.0, 112.9, 456.1, 298.8, 55.0, 80.0);
        
        System.out.println("Is M1 at its destination? " + m1.atDestination());
        System.out.println("Is M2 at its destination? " + m2.atDestination());
        System.out.println();
        
        System.out.println("M1 Location: " + m1.getLocation());
        System.out.println("M1 Destination: " + m1.getDestination());
        m1.update(5000);
        System.out.println("M1 Location after moving for 5 seconds: " + m1.getLocation());
        System.out.println();
        
        System.out.println("M2 Location: " + m2.getLocation());
        System.out.println("M2 Destination: " + m2.getDestination());
        m2.update(5000);
        System.out.println("M2 Location after moving for 5 seconds: " + m2.getLocation());
        System.out.println();
        
        System.out.println("M1 Location: " + m1.getLocation());
        System.out.println("M1 Destination: " + m1.getDestination());
        m1.update(25000);
        System.out.println("M1 Location after moving for 25 seconds: " + m1.getLocation());
        System.out.println("Is M1 at its destination? " + m1.atDestination());
        System.out.println();  
    }
    
    
    private static void makeLocation() throws InvalidDataException {

        Locatable l1 = new LocatableImpl(new Point3D(100.2, 202.5, 141.7));
        Locatable l2 = new LocatableImpl(10.5, 383.9, 27.6);

        System.out.println("L1 Location: " + l1.getLocation());
        System.out.println();
        
        System.out.println("L2 X-coord: " + l2.getLocationX());
        System.out.println("L2 Y-coord: " + l2.getLocationY());
        System.out.println("L2 Z-coord: " + l2.getLocationZ());
        System.out.println();
        
        System.out.println(String.format("Distance from L1 to L2: %.1f", l1.distance(l2.getLocation())));
        System.out.println(String.format("Distance from L2 to (100.0, 100.0, 100.0): %.1f", l2.distance(100.0, 100.0, 100.0)));
        System.out.println();
        
        l1.setLocation(10.0, 20.0, 30.0);
        System.out.println("New L1 Location: " + l1.getLocation());
        System.out.println();
        
    }

    private static void makeIdentification() throws InvalidDataException {

        Identifiable i1 = new IdentifiableImpl("Identifier Number 1");
        Identifiable i2 = new IdentifiableImpl("Identifier Number 2");
        Identifiable i3 = new IdentifiableImpl("Identifier Number 3");
        Identifiable i4 = new IdentifiableImpl("Identifier Number 4");

        System.out.println("I1: " + i1.getIdentifier());
        System.out.println("I2: " + i2.getIdentifier());
        System.out.println("I3: " + i3.getIdentifier());
        System.out.println("I4: " + i4.getIdentifier());
        System.out.println();
    }

    private static void makePoints() {

        Point3D p1 = new Point3D(100.2, 202.5, 141.7);
        Point3D p2 = new Point3D(55.3, 212, 0);
        Point3D p3 = new Point3D(p2);
        Point3D p4 = new Point3D();

        System.out.println("Point 1: " + p1);
        System.out.println("Point 2: " + p2);
        System.out.println("Point 3: " + p3);
        System.out.println("Point 4: " + p4);
        System.out.println();

        System.out.println(String.format("Distance P1 to P2: %.1f", p1.distance(p2)));
        System.out.println(String.format("Distance P2 to P4: %.1f", p2.distance(p4)));
        System.out.println();

        System.out.println("Is P3 equal to P4? " + p3.equals(p4));
        System.out.println("Is P2 equal to P3? " + p2.equals(p3));
        System.out.println();
    }
}
