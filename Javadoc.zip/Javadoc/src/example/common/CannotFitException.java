package example.common;

public class CannotFitException extends Exception {

    public CannotFitException(String msg) {
        super(msg);
    }
}
