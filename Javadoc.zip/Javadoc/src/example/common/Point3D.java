//Contains @link, @see, @author, @param, @return
package example.common;

import java.awt.Point;

/**
 * A class representing a 3D point in space. The 3D point has X, Y, and Z
 * {@link #setCoordinates coordinates}, which comprise its
 * {@link #setLocation location}.
 *
 * @since 1.0
 * @see java.awt.Point
 * @author Eric Lee
 */
public class Point3D extends Point.Double {

    /**
     * The Z-coordinate of the 3D point.
     *
     * @see #getZ()
     */
    public double z;

    /**
     * Generates a new 3D Point object with a given location based on the
     * coordinates entered.
     *
     * @param xIn The X coordinate of the new 3D point
     * @param yIn The Y coordinate of the new 3D point
     * @param zIn The Z coordinate of the new 3D point
     */
    public Point3D(double xIn, double yIn, double zIn) {
        setCoordinates(xIn, yIn, zIn);
    }

    /**
     * Generates a new 3D Point object with a given X and Y location, based on
     * the coordinates entered. This two parameter constructor sets the X and Y
     * coordinates, and defaults the Z coordinate to 0.
     *
     * @param xIn The X coordinate of the new 3D point
     * @param yIn The Y coordinate of the new 3D point
     */
    public Point3D(double xIn, double yIn) {
        setCoordinates(xIn, yIn, 0.0);
    }

    /**
     * Generates a new 3D Point object with a given location, based on another
     * Point object. The location of the new point will be set to the location
     * of the input point object.
     *
     * @param aPoint The 3D point object used to
     */
    public Point3D(Point3D aPoint) {
        setCoordinates(aPoint.getX(), aPoint.getY(), aPoint.getZ());
    }

    /**
     * Generates a new 3D Point object with a location of 0, 0, 0.
     */
    public Point3D() {
    }

    /**
     * Returns the Z coordinate of the 3D point object.
     *
     * @return The Z coordinate of the 3D point object.
     */
    public double getZ() {
        return z;
    }

    /**
     * Sets the 3 coordinate values for this 3D point object based on 3 input
     * coordinates.
     *
     * @param xIn The X coordinate of the desired location
     * @param yIn The Y coordinate of the desired location
     * @param zIn The Z coordinate of the desired location
     */
    public final void setCoordinates(double xIn, double yIn, double zIn) {
        x = xIn;
        y = yIn;
        z = zIn;

    }

    /**
     * Sets the location of the 3D point object based on the coordinates of a
     * different 3D point object.
     *
     * @param aPoint The 3D point object from which a location is derived
     */
    public void setLocation(Point3D aPoint) {
        setCoordinates(aPoint);
    }

    /**
     * Sets the location of the 3D point object based on 3 coordinate values.
     *
     * @param xIn The X coordinate of the desired location
     * @param yIn The Y coordinate of the desired location
     * @param zIn The Z coordinate of the desired location
     */
    public void setLocation(double xIn, double yIn, double zIn) {
        setCoordinates(xIn, yIn, zIn);
    }

    /**
     * Sets the coordinate values of the 3D point object. These coordinate
     * values are derived from another object's coordinate values.
     *
     * @param aPoint The 3D point object from which the coordinates are set.
     */
    public void setCoordinates(Point3D aPoint) {
        setCoordinates(aPoint.getX(), aPoint.getY(), aPoint.getZ());
    }

    /**
     * Returns the location of the 3D point object in the format (X, Y, Z).
     *
     * @return Returns a string containing the X, Y, and Z coordinates of the
     * Point
     */
    @Override
    public String toString() {
        return String.format("[%-1.2f, %-1.2f, %-1.2f]", x, y, z);
    }

    /**
     * Returns the distance between this 3D point object and the coordinates
     * passed through.
     *
     *
     * @param xIn The X coordinate of the location for calculating distance
     * @param yIn The Y coordinate of the location for calculating distance
     * @param zIn The Z coordinate of the location for calculating distance
     * @return The distance between this 3D point object and the entered
     * location
     */
    public double distance(double xIn, double yIn, double zIn) {
        xIn -= getX();
        yIn -= getY();
        zIn -= getZ();

        return Math.sqrt(xIn * xIn + yIn * yIn + zIn * zIn);
    }

    /**
     * Returns the distance between this 3D point and the location of another 3D
     * point object passed through.
     *
     * @param aPoint The 3D point object to whose location the distance is
     * calculated
     * @return The distance between this 3D point object and the location of the
     * passed-through 3D point object.
     */
    public double distance(Point3D aPoint) {
        return distance(aPoint.getX(), aPoint.getY(), aPoint.getZ());
    }

    /**
     * Returns true if the passed-in 3D point object's location is the same as
     * this 3D point object's location.
     *
     * @param aPoint3D The 3D point object used for comparison
     * @return Boolean based on location coordinates of the two objects.
     */
    public boolean equals(Point3D aPoint3D) {
        return (getX() == aPoint3D.getX())
                && (getY() == aPoint3D.getY())
                && (getZ() == aPoint3D.getZ());
    }
}
