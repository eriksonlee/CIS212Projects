package assignment2;


public class AlreadyExistsException extends Exception {

    public AlreadyExistsException(String s) {
        super(s);
    }
}
